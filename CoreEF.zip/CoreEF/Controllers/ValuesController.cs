﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CoreEF.Models;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreEF.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        private readonly EmpDbContext _context;
        public ValuesController(EmpDbContext context)
        {
            _context = context;
        }
        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
       
        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
     
        [HttpPost]
        public JsonResult Post([FromBody] tblSkill o)
        {
            _context.tblSkills.Add(o);
            _context.SaveChanges();
            // return Content("success");
            // return "hel";
            return Json(new

            {

                msg = "Successfully added "

            });

        
    }

        // PUT api/<controller>/5
        [HttpPut]
        public JsonResult Put(tblSkill o)
        {
        //   var tblskill = _context.tblSkills.Find(o.SkillID);
          //  tblskill.SkillID = o.SkillID;
          //  tblskill.St = "abcd";
        //   tblskill.Title = o.Title;
         //   _context.Entry(o).State= System.Data.Entity.
             _context.Update(o);
            _context.SaveChanges();
            return Json(new { msg = "Register successfully" });
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            var tblskill = _context.tblSkills.Find(id);
            _context.tblSkills.Remove(tblskill);
            _context.SaveChanges();
            return Json(new { msg = "Register successfully" });
        }
    }
}
